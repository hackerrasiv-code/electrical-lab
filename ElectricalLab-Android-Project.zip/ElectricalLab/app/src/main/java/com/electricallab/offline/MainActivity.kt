package com.electricallab.offline

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*

private data class Lesson(val title: String, val category: String, val description: String, val task: String)

class MainActivity : Activity() {
    private val lessons = listOf(
        Lesson("Relay logic", "CONTROL", "Explore relay coils, NO/NC contact states and control logic in a low-voltage virtual model.", "Operate the virtual control input. Observe how the simulated relay state changes."),
        Lesson("Star–delta motor", "MOTOR CONTROL", "Study the sequence of a simulated reduced-start motor controller and its timer states.", "Start the model and observe the transition from the initial state to the running state."),
        Lesson("DOL starter", "MOTOR CONTROL", "Explore a basic direct-on-line starter as a logic model with start, stop and overload states.", "Start the model, then test the stop and overload functions."),
        Lesson("Forward / reverse", "MOTOR CONTROL", "Learn how an interlocked direction-control model prevents both directions being active together.", "Select one direction, then try selecting the other direction."),
        Lesson("Contactor & overload", "PROTECTION", "Identify the simulated contactor, auxiliary status and overload trip indication.", "Run the model, then trigger the virtual overload test."),
        Lesson("Industrial sensors", "SENSORS", "Compare proximity, photoelectric and limit-switch input behaviour.", "Toggle the target-present input and observe the sensor output."),
        Lesson("SMPS concepts", "POWER SUPPLY", "Explore a conceptual AC-input / DC-output power-supply block and its status indicators.", "Switch the virtual input on and inspect the output status."),
        Lesson("Virtual multimeter", "TEST EQUIPMENT", "Practise choosing a measurement mode and reading a simulated value.", "Choose voltage, resistance or continuity mode, then take a virtual reading.")
    )
    private var selected = 0
    private var running = false
    private var auxiliary = false
    private var direction = "STOP"
    private var meterMode = "Voltage"
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var status: TextView
    private lateinit var actionButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(12, 18, 32)
        window.navigationBarColor = Color.rgb(12, 18, 32)
        showHome()
    }

    private fun base(title: String, subtitle: String) {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(10, 16, 29)) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 22, 20, 18); setBackgroundColor(Color.rgb(17, 27, 46)) }
        header.addView(label("⚡  ELECTRICAL LAB", 13, Color.rgb(75, 210, 190), true))
        header.addView(label(title, 25, Color.WHITE, true).apply { setPadding(0, 9, 0, 3) })
        header.addView(label(subtitle, 13, Color.rgb(177, 190, 210), false))
        root.addView(header)
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 16, 16, 26) }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun showHome() {
        base("Industrial training", "Offline virtual practice • Learn the logic safely")
        card("TRAINING MODULES", "Choose a virtual exercise. Each module runs locally and works without internet.")
        lessons.forEachIndexed { index, lesson ->
            val item = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(15, 13, 15, 13); background = bg(Color.rgb(23, 34, 54), 14); isClickable = true; isFocusable = true }
            item.addView(label(lesson.title, 17, Color.WHITE, true))
            item.addView(label(lesson.category, 10, Color.rgb(75, 210, 190), true).apply { setPadding(0, 4, 0, 5) })
            item.addView(label(lesson.description, 13, Color.rgb(190, 201, 217), false))
            item.setOnClickListener { selected = index; running = false; auxiliary = false; direction = "STOP"; showLab() }
            content.addView(item, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10 })
        }
        card("SAFETY NOTE", "This is an educational software model, not a wiring diagram or commissioning guide. Never use it to work on mains or industrial equipment. Real installations require qualified supervision and approved procedures.")
        content.addView(label("Version 1.0 • Runs offline after installation", 11, Color.GRAY, false).apply { setPadding(3, 14, 3, 0) })
    }

    private fun showLab() {
        val lesson = lessons[selected]
        base(lesson.title, "${lesson.category}  •  VIRTUAL TRAINING BOARD")
        val back = button("←  All modules") { showHome() }
        content.addView(back, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 12 })
        card("EXERCISE", lesson.task)
        val board = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 16, 16, 16); background = bg(Color.rgb(18, 39, 48), 16) }
        board.addView(label("SIMULATION PANEL", 11, Color.rgb(75, 210, 190), true))
        board.addView(label(visualFor(selected), 19, Color.WHITE, true).apply { gravity = Gravity.CENTER; setPadding(0, 20, 0, 20) })
        status = label(statusText(), 14, Color.rgb(220, 230, 240), true).apply { gravity = Gravity.CENTER; setPadding(8, 12, 8, 12); background = bg(Color.rgb(30, 53, 63), 10) }
        board.addView(status)
        content.addView(board, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 12 })
        when (selected) {
            3 -> {
                content.addView(label("Direction input", 14, Color.WHITE, true))
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                row.addView(button("Forward") { direction = if (direction == "FORWARD") "STOP" else "FORWARD"; refreshStatus() }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = 6 })
                row.addView(button("Reverse") { direction = if (direction == "REVERSE") "STOP" else "REVERSE"; refreshStatus() }, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = 6 })
                content.addView(row)
                content.addView(button("Stop") { direction = "STOP"; refreshStatus() })
            }
            5 -> content.addView(button("Toggle target present") { auxiliary = !auxiliary; refreshStatus() })
            7 -> {
                content.addView(label("Meter mode", 14, Color.WHITE, true))
                val spinner = Spinner(this)
                spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("Voltage", "Resistance", "Continuity"))
                spinner.setSelection(0)
                spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                    override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
                    override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { meterMode = listOf("Voltage", "Resistance", "Continuity")[position]; refreshStatus() }
                }
                content.addView(spinner)
                content.addView(button("Take virtual reading") { auxiliary = true; refreshStatus() })
            }
            else -> {
                actionButton = button(if (running) "Reset model" else "Run simulation") { running = !running; auxiliary = false; refreshStatus(); actionButton.text = if (running) "Reset model" else "Run simulation" }
                content.addView(actionButton)
                if (selected == 4) content.addView(button("Trigger virtual overload test") { auxiliary = true; refreshStatus() })
            }
        }
        content.addView(label("OBSERVATION", 11, Color.rgb(75, 210, 190), true).apply { setPadding(0, 18, 0, 5) })
        content.addView(label(observation(), 13, Color.rgb(190, 201, 217), false))
        content.addView(label("Learning model only: component labels and states are conceptual. No real-world terminal numbers, mains wiring instructions or live-equipment procedures are provided.", 11, Color.rgb(235, 190, 120), false).apply { setPadding(0, 18, 0, 0) })
    }

    private fun visualFor(i: Int) = when (i) {
        0 -> "[ CONTROL INPUT ]  →  ( RELAY )  →  [ OUTPUT ]"
        1 -> "[ START ]  →  [ STARTING STATE ]  →  [ RUN ]"
        2 -> "[ START / STOP ]  →  [ MOTOR MODEL ]"
        3 -> "[ FORWARD ]  ⇄  [ INTERLOCK ]  ⇄  [ REVERSE ]"
        4 -> "[ CONTACTOR ]  •  [ OVERLOAD STATUS ]"
        5 -> "[ SENSOR ]  →  [ INPUT STATUS ]"
        6 -> "[ AC CONCEPT ]  →  [ SMPS MODEL ]  →  [ DC STATUS ]"
        else -> "[ METER ]  •  SELECT MODE  •  READ"
    }

    private fun statusText(): String = when (selected) {
        3 -> "Direction: $direction  |  Interlock: ${if (direction == "STOP") "Idle" else "One direction active"}"
        5 -> "Sensor output: ${if (auxiliary) "DETECTED" else "NOT DETECTED"}"
        7 -> if (auxiliary) when (meterMode) { "Voltage" -> "Virtual reading: 12.0 V DC"; "Resistance" -> "Virtual reading: 220 Ω"; else -> "Continuity: BEEP (model path closed)" } else "Meter ready • Mode: $meterMode"
        4 -> if (auxiliary) "OVERLOAD TEST: TRIPPED • Output disabled" else if (running) "Contactor model: ENERGISED • Protection normal" else "Contactor model: DE-ENERGISED"
        6 -> if (running) "Input model: ON • DC output status: AVAILABLE" else "Input model: OFF • DC output status: OFF"
        else -> if (running) "Simulation: ACTIVE • Output state: ON" else "Simulation: IDLE • Output state: OFF"
    }

    private fun observation() = when (selected) {
        0 -> "A relay model changes its output state when its control condition is active. NO and NC describe contact states relative to the de-energised condition."
        1 -> "The training sequence illustrates a timed change between two abstract operating states. Real motor starter design and protection must be verified by a qualified person."
        2 -> "The model responds to start and stop commands. An overload condition should take the system to a safe stopped state."
        3 -> "The direction model allows only one direction request at a time. This demonstrates the purpose of interlocking."
        4 -> "A protection trip removes the simulated output. Reset the model before another run."
        5 -> "A sensor changes its output state when the simulated target input changes. Different sensor technologies detect targets in different ways."
        6 -> "The SMPS block represents conversion at a conceptual level. Actual power supplies contain hazardous stored energy and require qualified service."
        else -> "The displayed values are fictional training values, not measurements from physical equipment."
    }

    private fun refreshStatus() { status.text = statusText() }
    private fun card(title: String, body: String) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(14, 13, 14, 13); background = bg(Color.rgb(23, 34, 54), 14) }
        box.addView(label(title, 11, Color.rgb(75, 210, 190), true))
        box.addView(label(body, 13, Color.rgb(200, 210, 225), false).apply { setPadding(0, 6, 0, 0) })
        content.addView(box, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 12 })
    }
    private fun label(text: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply { this.text = text; textSize = size.toFloat(); setTextColor(color); if (bold) setTypeface(null, Typeface.BOLD); setPadding(0, 2, 0, 2) }
    private fun button(text: String, click: () -> Unit) = Button(this).apply { this.text = text; isAllCaps = false; textSize = 14f; setOnClickListener { click() } }
    private fun bg(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = radius.toFloat() }
}
