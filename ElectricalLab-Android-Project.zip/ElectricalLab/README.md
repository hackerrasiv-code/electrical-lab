# Electrical Lab (Android source project)

A small offline Android training app with interactive conceptual exercises for relay logic, star-delta sequence, DOL, direction interlocking, contactor/overload status, sensors, SMPS concepts, and a fictional virtual meter.

## Open and build
1. Install Android Studio on a computer.
2. Open this `ElectricalLab` folder (the folder containing `settings.gradle`).
3. Allow Gradle to sync. Android Studio may download the Android Gradle Plugin and Kotlin plugin once.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The APK is normally created at `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer that APK to your Android phone and install it. Android may ask you to allow installation from that file manager.

## Offline behaviour
The app makes no network requests and has no internet permission. The initial Android Studio build needs internet to fetch the build tools/dependencies; the installed app itself works offline.

## Scope and safety
This is a conceptual training simulator, not an electrical CAD package, wiring reference, commissioning guide, or substitute for qualified instruction. The sample readings are fictional. It deliberately avoids real terminal-by-terminal mains wiring instructions. Do not use it to work on live equipment.

## Requirements
- Android Studio with Android SDK Platform 35 installed (or let Android Studio install it).
- JDK 17 (Android Studio's bundled JBR is suitable).
